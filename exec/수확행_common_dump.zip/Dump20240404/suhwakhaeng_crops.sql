CREATE DATABASE  IF NOT EXISTS `suhwakhaeng` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `suhwakhaeng`;
-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: suhwakhaeng-db.choem88ukglc.ap-northeast-2.rds.amazonaws.com    Database: suhwakhaeng
-- ------------------------------------------------------
-- Server version	8.0.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `crops`
--

DROP TABLE IF EXISTS `crops`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `crops` (
  `crops_id` bigint NOT NULL AUTO_INCREMENT,
  `crops_disease_type` varchar(255) DEFAULT NULL,
  `crops_growing_condition` text,
  `crops_name` varchar(255) DEFAULT NULL,
  `crops_pest_type` varchar(255) DEFAULT NULL,
  `crops_category` enum('FOOD_CROPS','VEGETABLE','FRUIT_TREE') DEFAULT NULL,
  PRIMARY KEY (`crops_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `crops`
--

LOCK TABLES `crops` WRITE;
/*!40000 ALTER TABLE `crops` DISABLE KEYS */;
INSERT INTO `crops` VALUES (1,'검은무늬썩음병, 겹둥근무늬병, 균핵병, 더뎅이병, 역병, 탄저병','적배적온 : 14~23℃|덩이줄기 비대 적온 : 주간 23~24℃, 야간 10~14℃|전 생육기간동안 필요한 강수량 : 300~450mm|적정 토양산도 : pH 5.0~6.0','감자','복숭아혹진딧물, 아메리카잎굴파리, 오이총채벌레, 청동방아벌레, 큰이십팔점박이무당벌레, 파밤나방','FOOD_CROPS'),(2,'검은점뿌리썩음병, 겹무늬병, 궤양병, 균핵병, 덤블위축바이러스, 모자이크병, 반점위조바이러스, 뿌리역병, 시들음병, 잎곰팡이병, 잎마름병, 잎마름역병, 잘록병, 잿빛곰팡이병, 점무늬병, 줄기끝마름병, 줄기무름병, 줄기속썩음병, 탄저병, 풋마름병, 황화잎말림바이러스, 흰가루병, 흰무늬병','생육온도 : 발아적온 25~30℃ 육묘적온 20~25℃ 개화적온 20~25℃ 생육적온 17~27℃ 과비대적온 25~30℃ 저장적온 4℃|재배적지 : 토양산도 pH 6.5~7.0 범위에서 생육양호','토마토','꽃노랑총채벌레, 담배가루이, 담배거세미나방, 대만총채벌레, 목화진딧물, 복숭아혹진딧물, 아메리카잎굴파리, 온실가루이, 왕담배나방, 토마토녹응애','VEGETABLE'),(3,'갈색점무늬병, 검은곰팡이병, 검은점열매썩음병, 겹무늬병, 궤양병, 균핵병, 꼭지썩음병, 누른모자이크병, 모자이크병, 무름병, 세균성무늬병, 시들음병, 역병, 옆맥투명병, 원형반점병, 위조병, 잘록병, 잿빛곰팡이병, 점무늬병, 탄저병, 풋마름병, 흰가루병, 흰무늬병',NULL,'고추','갈색날개매미충, 꽃노랑총재벌레, 담배거세미나방, 담배나방, 목화진딧물, 복숭아혹진딧물, 아메리카잎굴파리, 오이총채벌레, 차먼지응애, 파밤나방','VEGETABLE'),(4,'갈색둥근무늬병, 갈색무늬병, 검은썩음병, 검은점뿌리썩음벼병, 겹무늬병, 균행병, 모자이크병, 시들음병, 역병, 잎곰팡이병, 잘록병, 잿빛곰팡이병, 점무늬병, 풋마름병, 흰가루병','생육온도 : 발아적온 22~30℃ 육묘적온 22~30℃ 야간적온 16~20℃ 생육적온 22~30℃ 평균온도 25~28℃ 저장적온 12~15℃','가지','꽃노랑총채벌레, 복숭아혹진딧물, 아메리카잎굴파리, 오이총채벌레, 왕담배나방, 점박이응애, 조합나무진딧물, 차먼지응애, 큰이십팔점박이무당벌레','VEGETABLE'),(5,'검은무늬병, 더뎅이병, 덩굴쪼김병, 모틀병, 무름병, 밑썩음병, 자주날개무늬병, 점균병, 점무늬병, 푸른곰팡이병, 흰비단병','발아 및 출현기 : 22~24℃ (지표적온 18~20℃)|생육적온 : 20~30℃','고구마','담배거세미나방, 명주달팽이, 섬서구메뚜기','FOOD_CROPS'),(6,'검은무늬병, 검은잎마름병, 관부썩음병, 균핵병, 마른썩음병, 모자이크병, 무름병, 점무늬병, 흰가루병','생육온도 : 발아적온 15~30℃ 개화적온 12℃ 생육적온 15~20℃ 근비대적온 16~21℃|재배적지 : 토양산도는 pH 6.0~6.5로서 중성내지 약산성 토양','당근','아메리카잎굴파리','VEGETABLE'),(7,'갈색잎마름병, 녹병, 마른썩음병, 모자이크병, 잎마름병, 잎집썩음병, 잿빛곰팡이병, 푸른곰팡이병, 흑색썩음균핵병','생육온도 : 발아적온 15~27℃ 동해온도 -5℃ 잎 생육적온 18~20℃ 생육 최저 4℃|재배적지 : 토양산도 pH 5.5~6.0 정도에서 생육양호','마늘','고자리파리, 뿌리응애, 파굴파리, 파좀나방','VEGETABLE'),(8,'갈섹무늬병, 균핵병, 노균병, 모자이크병, 무름병, 밑둥썩음병, 뿌리썩음병, 시들음병, 역병, 잎썩음병, 잿빛곰파이병','생육온도 : 발아적온 15~20℃ 육묘적온 18~20℃ 생육적온 15~20℃ 최적지온 20℃ 저장적온 0℃|재배적지 : 토양 산도는 pH 6.6~7.2 정도로 5이하의 산성토양에서 생육저하','상추','명주달팽이, 아메리카잎굴파리, 왕담배나방','VEGETABLE'),(9,'검은벽무늬병, 검은점뿌리썩음병, 과실썩음병, 괴저반점바이러스병, 균핵병, 덩굴마름병, 덩굴쪼김병, 모자이크병, 얼룩모자이크병, 역병, 잎마름병, 잘록병, 잿빛곰팡이병, 점무늬병, 탄저병, 흰가루병','생육온도 : 발아적온 28~30℃ 개화적온 15~20℃ 생육적온 25~30℃ 근비대적온 20℃ 저장적온 3~10℃|재배적지 : 토양산도는 pH 5.5~6.8정도이며, 심토가 깊은 사질양토','수박','담배거세미나방, 명주달팽이, 목화진딧물, 아메리카잎굴파리, 오이총채벌레, 점박이응애, 파밤나방','VEGETABLE'),(10,'검은무늬병, 검은점무늬마름병, 깜부기병, 노균병, 누른오갈병, 무름병, 세균썩음병, 시들음병, 잎마름병, 잘록병, 잿빛곰팡이병, 쿠키병2, 푸른곰팡이병, 흑색썩음균행병','생육온도 : 발아적온 15~25℃ 생육적온 17℃전후 구비대적온 15(조)~20(중만)℃ 고온장해 25℃이상|재배적지 : 토양산도 pH 6.3~7.3 정도에서 생육양호','양파','뿌리응애, 파총패벌레','VEGETABLE'),(11,'검은별무늬병, 균핵병, 노균병, 덩굴마름병, 덩굴쪼김병, 모자이크병, 세균성모무늬병, 세균성시들음병, 얼룩(綠斑)모자이크병, 역병, 잘록병, 잿빛곰팡이병, 탄저병, 흰가루병','생육온도 : 발아적온 25~30℃ 육묘적온 18~25℃ 생육적온 20~25℃ 근권적온 20~23℃ 저장적온 5~10℃|재배적지 : 토양산도 pH 5.5~6.8에서 생육이 좋고, pH 4.3이하에서는 고사','오이','꽃노랑총채벌레, 담배가루이, 담배거세미나방, 대만총채벌레, 명주달팽이, 목화진딧물, 아메리카잎굴파리, 오이총채벌레, 온실가루이, 왕담배나방, 작은뿌리파리, 점박이응애','VEGETABLE'),(12,'검은무늬병, 노균병, 녹병, 누른오갈병, 무름병, 시들음병, 잎마름병, 잘록병, 잿빛곰팡이병, 황색점무늬병, 흑색썩음균핵병','생육온도 : 15~20℃ 발아 적온 15~25℃ (변온)|재배적지 : pH 6.0(약산성, 중성)','파','담배거세미나방, 명주달팽이, 파굴파리, 파밤나방, 파좀나방','VEGETABLE'),(13,NULL,'생육온도 : 발아적온 24~25℃ 육묘적온 22~25℃ 야간적온 16~18℃|생육적온 : 22~25℃ 평균온도 18~21℃ 저장적온 10~12℃','파프리카',NULL,'VEGETABLE'),(14,'검은별무늬병, 규리얼룩모자이크, 균핵병, 노균병, 노귱병+D46, 누른모자이크병, 덩굴마름병, 덩굴쪼김병, 모자이크병, 뿌리썩음병, 역병, 잘록병, 잿빛곰팡이병, 탄저병, 흰가루병','생육온도 : 발아적온 25~30℃ 육묘적온 18~21℃ 생육적온 20~25℃ 저장적온 7~10℃','호박','담배거세미나방, 작은뿌리파리','VEGETABLE');
/*!40000 ALTER TABLE `crops` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-04-04 10:44:22
