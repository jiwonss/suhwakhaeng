CREATE DATABASE  IF NOT EXISTS `suhwakhaeng` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `suhwakhaeng`;
-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: suhwakhaeng-db.choem88ukglc.ap-northeast-2.rds.amazonaws.com    Database: suhwakhaeng
-- ------------------------------------------------------
-- Server version	8.0.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `trade_board`
--

DROP TABLE IF EXISTS `trade_board`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `trade_board` (
  `x` double DEFAULT NULL,
  `y` double DEFAULT NULL,
  `created_at` datetime(6) DEFAULT NULL,
  `trade_board_id` bigint NOT NULL AUTO_INCREMENT,
  `trade_board_price` bigint DEFAULT NULL,
  `updated_at` datetime(6) DEFAULT NULL,
  `user_id` bigint NOT NULL,
  `road_name_address` varchar(255) DEFAULT NULL,
  `trade_board_content` text,
  `trade_board_image1` varchar(255) DEFAULT NULL,
  `trade_board_image2` varchar(255) DEFAULT NULL,
  `trade_board_image3` varchar(255) DEFAULT NULL,
  `trade_board_image4` varchar(255) DEFAULT NULL,
  `trade_board_title` varchar(255) DEFAULT NULL,
  `trade_cate` enum('CROP','MATERIAL','EXPERIENCE','WORK') DEFAULT NULL,
  `trade_status` enum('SALE','COMPLETE') DEFAULT NULL,
  PRIMARY KEY (`trade_board_id`),
  KEY `FKgj5q9jor9sitms9uuxmx05769` (`user_id`),
  CONSTRAINT `FKgj5q9jor9sitms9uuxmx05769` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trade_board`
--

LOCK TABLES `trade_board` WRITE;
/*!40000 ALTER TABLE `trade_board` DISABLE KEYS */;
INSERT INTO `trade_board` VALUES (126.931096692273,35.1815858721435,'2024-04-03 11:15:11.179156',2,5900,'2024-04-03 12:08:55.451664',1,'광주 북구 각화대로 2','감자 1키로','https://firebasestorage.googleapis.com/v0/b/suhwakhaeng-d9373.appspot.com/o/images%2F%EC%9E%A5%ED%84%B0%2F1%2F2%2Fimage_0.png?alt=media&token=2f6af972-87a3-49f4-8e51-c6ebf823c22d',NULL,NULL,NULL,'감자','CROP','SALE'),(0,0,'2024-04-03 11:16:55.668164',3,6000,'2024-04-03 11:16:55.668164',3,'','감자팔아요','https://firebasestorage.googleapis.com/v0/b/suhwakhaeng-d9373.appspot.com/o/images%2F%EC%9E%A5%ED%84%B0%2F3%2F2024-04-03%2011%3A16%3A50%2Fimage_0.png?alt=media&token=939013e8-869d-46bb-8e26-c98bc07ca567',NULL,NULL,NULL,'감자','CROP','SALE'),(0,0,'2024-04-03 12:08:08.845295',5,4000,'2024-04-03 12:09:24.858416',1,'','청양고추 500g','https://firebasestorage.googleapis.com/v0/b/suhwakhaeng-d9373.appspot.com/o/images%2F%EC%9E%A5%ED%84%B0%2F1%2F2024-04-03%2012%3A08%3A06%2Fimage_0.png?alt=media&token=1332bdd3-8ca4-4467-b9fe-edea212681d6',NULL,NULL,NULL,'청양고추','CROP','COMPLETE'),(126.717924374412,34.9945522438241,'2024-04-03 12:10:33.763230',6,10000,'2024-04-03 12:10:33.763230',1,'전남 나주시 가마태길 13','고구마 2kg','https://firebasestorage.googleapis.com/v0/b/suhwakhaeng-d9373.appspot.com/o/images%2F%EC%9E%A5%ED%84%B0%2F1%2F2024-04-03%2012%3A10%3A32%2Fimage_0.png?alt=media&token=4772525f-d146-470b-89f3-20b56c9dc084',NULL,NULL,NULL,'고구마','CROP','SALE'),(0,0,'2024-04-03 12:13:51.913393',7,3000,'2024-04-03 12:13:51.913393',1,'','양파 500g','https://firebasestorage.googleapis.com/v0/b/suhwakhaeng-d9373.appspot.com/o/images%2F%EC%9E%A5%ED%84%B0%2F1%2F2024-04-03%2012%3A13%3A49%2Fimage_0.png?alt=media&token=2d1e3f4c-efc6-42df-af32-63301a80e19c',NULL,NULL,NULL,'양파','CROP','SALE'),(127.023150432187,37.5182112402056,'2024-04-03 12:15:13.525774',8,2000,'2024-04-03 14:12:50.187967',1,'서울 강남구 가로수길 5','마늘 200g','https://firebasestorage.googleapis.com/v0/b/suhwakhaeng-d9373.appspot.com/o/images%2F%EC%9E%A5%ED%84%B0%2F1%2F8%2Fimage_0.png?alt=media&token=b5e3eb79-47f3-446a-93f0-22f1eb308a78',NULL,NULL,NULL,'마늘','CROP','COMPLETE'),(129.265265151149,35.3594903331713,'2024-04-03 14:19:35.025572',13,5000,'2024-04-04 09:05:40.390808',3,'부산 기장군 장안읍 판곡길 2','양파 팔아요~','https://firebasestorage.googleapis.com/v0/b/suhwakhaeng-d9373.appspot.com/o/images%2F%EC%9E%A5%ED%84%B0%2F3%2F13%2Fimage_0.png?alt=media&token=b21d81eb-0cc6-4712-848b-f1a5a7db5703','https://firebasestorage.googleapis.com/v0/b/suhwakhaeng-d9373.appspot.com/o/images%2F%EC%9E%A5%ED%84%B0%2F3%2F13%2Fimage_1.png?alt=media&token=771cd95e-f22c-4b05-9a5b-7311f24ec16e','https://firebasestorage.googleapis.com/v0/b/suhwakhaeng-d9373.appspot.com/o/images%2F%EC%9E%A5%ED%84%B0%2F3%2F13%2Fimage_2.png?alt=media&token=d1c77fef-7a7d-4eab-be41-187224d0b802',NULL,'양파','CROP','SALE'),(126.809422341063,35.1905456057988,'2024-04-03 23:31:41.045829',21,50000,'2024-04-03 23:32:17.137602',52,'광주 광산구 사암로 519','고춧잎 팝니다!!!','https://firebasestorage.googleapis.com/v0/b/suhwakhaeng-d9373.appspot.com/o/images%2F%EC%9E%A5%ED%84%B0%2F52%2F21%2Fimage_0.png?alt=media&token=4f8ec9c8-522c-4174-9bdd-fe6b8399de7a',NULL,NULL,NULL,'고춧잎 팔아요','CROP','COMPLETE'),(126.701987254003,35.1713663299253,'2024-04-04 10:20:17.482057',25,0,'2024-04-04 10:20:17.482057',1,'광주 광산구 가마길 8','감자 키우기 체험 어떠세요??\n참여 하실분은 채팅 부탁드립니다!','https://firebasestorage.googleapis.com/v0/b/suhwakhaeng-d9373.appspot.com/o/images%2F%EC%9E%A5%ED%84%B0%2F1%2F2024-04-04%2010%3A20%3A14%2Fimage_0.png?alt=media&token=fb30d80b-03a7-4375-9213-c12b9b6fb851',NULL,NULL,NULL,'저희 텃밭에서 감자 키우기 체험하실분~','EXPERIENCE','SALE'),(0,0,'2024-04-04 10:21:25.242145',26,0,'2024-04-04 10:21:25.242145',1,'','감순이와 놀아주실분을 찾습니다!\n저희 감순이는 아주 착한 감자랍니다!','https://firebasestorage.googleapis.com/v0/b/suhwakhaeng-d9373.appspot.com/o/images%2F%EC%9E%A5%ED%84%B0%2F1%2F2024-04-04%2010%3A21%3A20%2Fimage_0.png?alt=media&token=31850268-b393-4734-af24-631d4b0bee6b',NULL,NULL,NULL,'감순이와 놀아주실분 찾습니다!','WORK','SALE'),(126.375422332008,33.2700064530738,'2024-04-04 10:24:08.258062',27,10000,'2024-04-04 10:24:26.138983',1,'제주특별자치도 서귀포시 가가로 14','같이 제주도로 귤 따러 오세요!\n아주 싱싱한 귤이 잔뜩 있답니다.','https://firebasestorage.googleapis.com/v0/b/suhwakhaeng-d9373.appspot.com/o/images%2F%EC%9E%A5%ED%84%B0%2F1%2F27%2Fimage_0.png?alt=media&token=a631e8e7-3dd6-4e10-9324-a5027f18d9c8',NULL,NULL,NULL,'귤 같이 따러 요세요~','EXPERIENCE','SALE'),(0,0,'2024-04-04 10:25:38.647756',28,30000,'2024-04-04 10:25:38.647756',1,'','농자재 팝니다.\n구매 하실분은 채팅주세요.','https://firebasestorage.googleapis.com/v0/b/suhwakhaeng-d9373.appspot.com/o/images%2F%EC%9E%A5%ED%84%B0%2F1%2F2024-04-04%2010%3A25%3A35%2Fimage_0.png?alt=media&token=3675b385-736a-4269-a136-8171801cc852',NULL,NULL,NULL,'농자재','MATERIAL','SALE'),(126.384405824548,34.7899580885794,'2024-04-04 10:26:54.855241',29,20000,'2024-04-04 10:26:54.855241',1,'전남 목포시 노적봉길 9','복숭아 팝니다!','https://firebasestorage.googleapis.com/v0/b/suhwakhaeng-d9373.appspot.com/o/images%2F%EC%9E%A5%ED%84%B0%2F1%2F2024-04-04%2010%3A26%3A52%2Fimage_0.png?alt=media&token=1b12963b-fc87-4c92-836b-06fee7a63ba9',NULL,NULL,NULL,'복숭아','CROP','SALE');
/*!40000 ALTER TABLE `trade_board` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-04-04 10:44:24
