CREATE DATABASE  IF NOT EXISTS `suhwakhaeng` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `suhwakhaeng`;
-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: suhwakhaeng-db.choem88ukglc.ap-northeast-2.rds.amazonaws.com    Database: suhwakhaeng
-- ------------------------------------------------------
-- Server version	8.0.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `community_comment`
--

DROP TABLE IF EXISTS `community_comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `community_comment` (
  `community_comment_id` bigint NOT NULL AUTO_INCREMENT,
  `community_comment_parent` bigint DEFAULT NULL,
  `community_id` bigint DEFAULT NULL,
  `created_at` datetime(6) DEFAULT NULL,
  `updated_at` datetime(6) DEFAULT NULL,
  `user_id` bigint DEFAULT NULL,
  `community_comment_content` text,
  PRIMARY KEY (`community_comment_id`),
  KEY `FK5s7mlxnl3exdg2iy49qjpjsp7` (`community_id`),
  KEY `FKmeg9k5406krwuvp8ujarws1e5` (`community_comment_parent`),
  KEY `FK9oaji7qtsspwvxbp5yuy5a5em` (`user_id`),
  CONSTRAINT `FK5s7mlxnl3exdg2iy49qjpjsp7` FOREIGN KEY (`community_id`) REFERENCES `community` (`community_id`),
  CONSTRAINT `FK9oaji7qtsspwvxbp5yuy5a5em` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`),
  CONSTRAINT `FKmeg9k5406krwuvp8ujarws1e5` FOREIGN KEY (`community_comment_parent`) REFERENCES `community_comment` (`community_comment_id`)
) ENGINE=InnoDB AUTO_INCREMENT=85 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `community_comment`
--

LOCK TABLES `community_comment` WRITE;
/*!40000 ALTER TABLE `community_comment` DISABLE KEYS */;
INSERT INTO `community_comment` VALUES (1,NULL,3,'2024-04-03 10:56:01.468613','2024-04-03 10:56:01.468613',3,'저랑 갈래요? 벚꽃 저도 보러가고 싶어요!'),(2,NULL,6,'2024-04-03 11:07:31.336996','2024-04-03 11:07:31.336996',1,'넵!'),(10,NULL,15,'2024-04-03 11:33:53.453497','2024-04-03 11:33:53.453497',4,'헐 고양이... 너무 귀여워요'),(11,NULL,20,'2024-04-03 11:41:01.032604','2024-04-03 11:41:01.032604',4,'헐 춘식이!!!!!'),(30,NULL,21,'2024-04-03 14:32:51.157445','2024-04-03 14:32:51.157445',1,'저 먹고싶어요'),(31,NULL,22,'2024-04-03 14:34:55.483437','2024-04-03 14:34:55.483437',1,'같이 가요~~~'),(32,NULL,22,'2024-04-03 14:35:26.544322','2024-04-03 14:35:26.544322',102,'빵 사주시면 가겠습니다!'),(33,NULL,21,'2024-04-03 14:35:37.250162','2024-04-03 14:35:37.250162',102,'저요'),(34,NULL,18,'2024-04-03 14:36:00.416592','2024-04-03 14:36:00.416592',102,'혹시 1세대 포켓몬도 있나요?'),(38,NULL,7,'2024-04-03 14:36:33.501019','2024-04-03 14:36:33.501019',102,'ㅋㅋㅋㅋㅋㅋㅋㅋㅋ'),(39,NULL,11,'2024-04-03 14:36:37.323367','2024-04-03 14:36:37.323367',52,'보여주세요'),(41,NULL,12,'2024-04-03 14:39:06.369165','2024-04-03 14:39:06.369165',52,'좋아요 ><'),(44,NULL,7,'2024-04-03 14:42:20.720632','2024-04-03 14:42:20.720632',1,'ㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋ 우와 정막 감사흡니다'),(45,38,7,'2024-04-03 14:42:26.089324','2024-04-03 14:42:26.805985',1,'메롱'),(71,NULL,21,'2024-04-03 17:38:15.805011','2024-04-03 17:38:15.805011',52,'너무 맛있어 보여요 !!!'),(72,NULL,20,'2024-04-03 17:47:17.789806','2024-04-03 17:47:17.789806',52,'헐 춘식이 너무 귀여워요 ><'),(82,NULL,27,'2024-04-04 09:24:40.836004','2024-04-04 09:24:40.836004',3,'공유 감사합니다'),(83,NULL,24,'2024-04-04 09:33:47.207989','2024-04-04 09:33:47.207989',3,'잘부탁드립니다');
/*!40000 ALTER TABLE `community_comment` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-04-04 10:44:25
