CREATE DATABASE  IF NOT EXISTS `suhwakhaeng` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `suhwakhaeng`;
-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: suhwakhaeng-db.choem88ukglc.ap-northeast-2.rds.amazonaws.com    Database: suhwakhaeng
-- ------------------------------------------------------
-- Server version	8.0.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `shipping_time_table`
--

DROP TABLE IF EXISTS `shipping_time_table`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shipping_time_table` (
  `crops_id` bigint DEFAULT NULL,
  `shipping_time_table_id` bigint NOT NULL AUTO_INCREMENT,
  `shipping_time_table_head` varchar(255) DEFAULT NULL,
  `shippping_time_table_title` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`shipping_time_table_id`),
  KEY `FKng6kb5uujo6xx45x44t60w5ff` (`crops_id`),
  CONSTRAINT `FKng6kb5uujo6xx45x44t60w5ff` FOREIGN KEY (`crops_id`) REFERENCES `crops` (`crops_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shipping_time_table`
--

LOCK TABLES `shipping_time_table` WRITE;
/*!40000 ALTER TABLE `shipping_time_table` DISABLE KEYS */;
INSERT INTO `shipping_time_table` VALUES (1,1,'작형,파종기,수확기,출하기,성출하기','겨울재배,봄재배,여름재배,가을재배'),(2,2,'작형,파종기,정식기,수확기,성출하기','촉성재배,반촉성재배,조숙재배,노지억제재배'),(3,3,'작형,파종기,정식기,수확기,성출하기','반촉성재배'),(4,4,'작형,파종기,정식기,수확기','촉형재배,반촉성재배'),(5,5,'작형,파종기,정식기,수확기, 성출하기','노지재배'),(6,6,'작형,파종기,수확기,주산지','하우스재배,터널재배,봄재배,여름재배,가을재배,월동재배'),(7,7,'작형,파종기,수확기,성출하기,저장용출하기','잎마늘 재배(노지)'),(8,8,'작형,파종기,정식기,수확기, 성출하기','시설 봄재배,여름재배,고랭지재배,가을재배,겨울재배'),(9,9,'작형,파종기,정식기,수확기,성출하기','촉성재배,반촉성재배,조숙재배,억제재배'),(10,10,'작형,파종기,정식기,수확기,성출하기,저장용출하기','보통재배,고랭지춘파,터널재배,자구재배'),(11,11,'작형,파종기,정식기,수확기,성출하기','촉성재배,반촉성재배,조숙재배,억제재배'),(12,12,'작형,파종기,수확기,주재배지역','노지(추파),시설 재배'),(13,13,'작형,파종기,정식기,수확기','촉성재배'),(14,14,'작형,파종기,정식기,수확기, 성출하기','노지재배');
/*!40000 ALTER TABLE `shipping_time_table` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-04-04 10:44:28
