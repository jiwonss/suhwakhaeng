CREATE DATABASE  IF NOT EXISTS `suhwakhaeng` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `suhwakhaeng`;
-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: suhwakhaeng-db.choem88ukglc.ap-northeast-2.rds.amazonaws.com    Database: suhwakhaeng
-- ------------------------------------------------------
-- Server version	8.0.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `diary`
--

DROP TABLE IF EXISTS `diary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `diary` (
  `diary_date` date DEFAULT NULL,
  `diary_id` bigint NOT NULL AUTO_INCREMENT,
  `my_crops_id` bigint NOT NULL,
  `diary_content` text,
  `diary_image` varchar(255) DEFAULT NULL,
  `diary_memo` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`diary_id`),
  KEY `FKamglel53b5jfib6ivsju4sw9t` (`my_crops_id`),
  CONSTRAINT `FKamglel53b5jfib6ivsju4sw9t` FOREIGN KEY (`my_crops_id`) REFERENCES `my_crops` (`my_crops_id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `diary`
--

LOCK TABLES `diary` WRITE;
/*!40000 ALTER TABLE `diary` DISABLE KEYS */;
INSERT INTO `diary` VALUES ('2024-04-04',17,157,'물주기','https://firebasestorage.googleapis.com/v0/b/suhwakhaeng-d9373.appspot.com/o/images%2F%EC%98%81%EB%86%8D%EC%9D%BC%EC%A7%80%2FThu%20Apr%2004%202024%2010%3A41%3A12%20GMT%2B0900%2F157%2Fimage_0.png?alt=media&token=51133b18-7d43-490f-9bc4-da1a2ebcfd4e',NULL),('2024-04-04',18,159,'바라보기','https://firebasestorage.googleapis.com/v0/b/suhwakhaeng-d9373.appspot.com/o/images%2F%EC%98%81%EB%86%8D%EC%9D%BC%EC%A7%80%2FThu%20Apr%2004%202024%2010%3A42%3A03%20GMT%2B0900%2F159%2Fimage_0.png?alt=media&token=5cb74333-c4a8-4b24-bfed-d36c205d5aaa','파파');
/*!40000 ALTER TABLE `diary` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-04-04 10:44:25
