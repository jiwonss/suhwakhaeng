CREATE DATABASE  IF NOT EXISTS `suhwakhaeng` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `suhwakhaeng`;
-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: suhwakhaeng-db.choem88ukglc.ap-northeast-2.rds.amazonaws.com    Database: suhwakhaeng
-- ------------------------------------------------------
-- Server version	8.0.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `user_id` bigint NOT NULL,
  `dong` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `gugun` varchar(255) DEFAULT NULL,
  `nickname` varchar(255) DEFAULT NULL,
  `profile_content` varchar(255) DEFAULT NULL,
  `profile_image` varchar(255) DEFAULT NULL,
  `provider_id` varchar(255) NOT NULL,
  `road_name_address` varchar(255) DEFAULT NULL,
  `sido` varchar(255) DEFAULT NULL,
  `provider` enum('KAKAO') NOT NULL,
  `role` enum('ADMIN','USER','FARMER','BUISNESS') DEFAULT NULL,
  `status` enum('RUN','EXIST','SLEEP') DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'오선동','sjs3326@naver.com','광산구','서지원','서지원짱','https://firebasestorage.googleapis.com/v0/b/suhwakhaeng-d9373.appspot.com/o/images%2F%ED%94%84%EB%A1%9C%ED%95%84%2F1%2Fimage_0.png?alt=media&token=46e57741-1adf-4d82-bbcb-aa02caf4ab1f','3395018641','광주 광산구 손재로 366-55','광주','KAKAO','ADMIN','RUN'),(2,'봉선동','flos9537@gmail.com','남구','오미쌍',NULL,'https://firebasestorage.googleapis.com/v0/b/suhwakhaeng-d9373.appspot.com/o/images%2F%ED%94%84%EB%A1%9C%ED%95%84%2F2%2Fimage_0.png?alt=media&token=d0e32429-4999-460f-99b7-536c70054229','3408031166','광주 남구 용대로 90','광주','KAKAO','BUISNESS','RUN'),(3,'팔판동','surin1009@naver.com','종로구','관리자','ㅂㅈㅂㅈㄱㅈㄱㅈ','https://firebasestorage.googleapis.com/v0/b/suhwakhaeng-d9373.appspot.com/o/images%2F%ED%94%84%EB%A1%9C%ED%95%84%2F3%2Fimage_0.png?alt=media&token=95629827-aa35-4cb4-a8fa-3e1e63eee070','3395023151','서울 종로구 팔판길 1-6','서울','KAKAO','ADMIN','RUN'),(4,NULL,'sjw.firebase001@gmail.com',NULL,'김싸피',NULL,'http://t1.kakaocdn.net/account_images/default_profile.jpeg.twg.thumb.R640x640','3419544412',NULL,NULL,'KAKAO','USER','RUN'),(52,NULL,'orol0520@naver.com',NULL,'조은서',NULL,'http://k.kakaocdn.net/dn/dqGhvk/btsFXaHgdnL/yZ3ONfnET9JKjFlb0YTzL1/img_640x640.jpg','3398601772',NULL,NULL,'KAKAO','ADMIN','RUN'),(102,'오전동','leeminkyu1212@kakao.com','의왕시','이민규',NULL,'https://firebasestorage.googleapis.com/v0/b/suhwakhaeng-d9373.appspot.com/o/images%2F%ED%94%84%EB%A1%9C%ED%95%84%2F102%2Fimage_0.png?alt=media&token=76a5411d-745b-4101-931f-953e77d0fff4','3416436514','경기 의왕시 경수대로 352','경기','KAKAO','BUISNESS','RUN'),(152,'금호동','eundeok9@gmail.com','서구','은덕',NULL,'https://firebasestorage.googleapis.com/v0/b/suhwakhaeng-d9373.appspot.com/o/images%2F%ED%94%84%EB%A1%9C%ED%95%84%2F152%2Fimage_0.png?alt=media&token=aa96193b-62f7-474d-af26-19cd95ef9aef','3418317897','광주 서구 마재로 3','광주','KAKAO','BUISNESS','RUN');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-04-04 10:44:29
