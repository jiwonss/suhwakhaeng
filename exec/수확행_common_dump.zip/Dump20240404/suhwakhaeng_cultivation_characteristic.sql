CREATE DATABASE  IF NOT EXISTS `suhwakhaeng` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `suhwakhaeng`;
-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: suhwakhaeng-db.choem88ukglc.ap-northeast-2.rds.amazonaws.com    Database: suhwakhaeng
-- ------------------------------------------------------
-- Server version	8.0.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `cultivation_characteristic`
--

DROP TABLE IF EXISTS `cultivation_characteristic`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cultivation_characteristic` (
  `crops_id` bigint DEFAULT NULL,
  `cultivation_characteristic_id` bigint NOT NULL AUTO_INCREMENT,
  `classification` varchar(255) DEFAULT NULL,
  `main_tech` text,
  `physiological_characteristic` text,
  `scientific_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`cultivation_characteristic_id`),
  UNIQUE KEY `UK_fma2k7vvic5lty85myph8sqcw` (`crops_id`),
  CONSTRAINT `FKrapwdyloyt2ldscnrl613txy` FOREIGN KEY (`crops_id`) REFERENCES `crops` (`crops_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cultivation_characteristic`
--

LOCK TABLES `cultivation_characteristic` WRITE;
/*!40000 ALTER TABLE `cultivation_characteristic` DISABLE KEYS */;
INSERT INTO `cultivation_characteristic` VALUES (2,1,'가지과','밀식재배 (90×50cm→90×20cm) : 93%증수|점적관수 재배 (분수관수 대비) : 6~10% 증수|이산화탄소 시비 : 무시용 대비 32% 증수|어린묘 재배 (9~11엽묘→5~6엽묘) : 43% 증수','호온성 채소이나 고온다습하면 착과불량, 과실비대 부진, 열과, 품질저하 및 병해발생 증가|육묘기 야간온도가 12℃ 이하의 저온에 처하면 기형과 발생증가|일장에 대해서는 중일성 작물이나 꽃눈분화는 16시간 정도의 장일에서 빨라지고, 제 1화방의 착과 절위는 8시간 정도의 단일하에서 낮아짐','Lycopersicum esculentum MILL.'),(3,2,'가지과','관비재배 (관행재배 대비 17% 증수, 시비 및 물 관리 시간 및 비용 82% 절감)|다겹보온 커튼 설치 (부직포 대비 연료절감 46%, 수량증수 12%)|하절기 재배 적정 육묘일수 : 72공 40일 육묘 (72공 60일 육묘 대비 11% 증수, 28% 소득증대 )','중일성 작물로 가지과에 속하는 영년생 작물임|가뭄에 강한 편이나 장마에는 약함(일명 : 한초)|)개화, 착과 가능온도 : 15.5℃~28.5℃|주당600~1,200화 정도가 개화하여 400~600 화정도 착과하며, 이중 200~300개 정도 수확이 가능함|꽃피는 주기는 일시에 피는 것이 아니고 3~4회의 주기|열매 크는 시기는 낮과 밤을 가리지 않고 지속적으로 자라지만 양분 이동 특성상 낮 70~80%, 초저녁에 20~30% 정도의 비율로 자람','Capsicum annuum L.'),(4,3,'가지과','유인시 U자형 45° 경사유인 : 노력절감 3.4시간/회/10a|2줄정식 2지주 유인 : 노력절감 11%|일소과 발생률 경감관리 : 3월~5월 오전 지표면 관수|CO₂ 500ppm +관비 : 수량 13% 증|일사감응 변온 : 연료 절감 2%, 수량 13% 증|측지 적심은 잎 전개 3일전 3절 위에서 적심|겨울철 한 낮 내피복 개폐 : 상품수량 15% 증|토양수분 장력계를 이용한 자동관수 : 관행대비 상품수량 11% 증|선충 발생지역에 톨루밤비가 대목 이용 : 선충 밀도 감소|가지는 영양제, 농약 등 약해에 민감하므로 사전에 2~3일 시험 후 처리','과일형태는 구형, 난(卵)형, 중장형, 장형, 대장형의 5가지 형태|고온성이며 건조보다는 습한 토양을 좋아하며 심근성 작물임 1번째 꽃은 7~14절에서 개화하며 2~3절 간격으로 다음 꽃 착화|영양생장과 생식생장을 동시에 하는 작물로 영양 균형 유지 필요','Solanum melongena L.'),(6,4,'산형화과','적정토양 수분관리에 의한 석회부족증 발생율 감소 : 자연강우시 75 %→적습유지시에는 발생이 되지 않음','서늘한 기후를 좋아하며, 내한성, 내서성이 강한편은 아님|꽃눈분화와 추대는 묘령에 관계없이 12℃이하의 저온에 감응하여 꽃눈분화가 촉진되고, 고온에 의해 추대가 촉진됨|고온에 의하여 품질이 낮아지는 페놀화합물 축적됨|뿌리 발육에는 포장 용수량의 65~80% 가 적당','Daucus carota L.'),(7,5,'백합과','우량품종 선발재배 (고흥종 등 재래종이 풍미 우수)|비닐덮기 재배 (무피복 대비 40~56% 증수)|대주아 유래 무병종구 재배 (이병 종구 대비 15% 증수)|파종 후 최대 10일간격 30mm 관수실시(무관수 대비 150% 증수)','발아 촉진을 위해서는 종구가 5℃이하에서 3주 경과되어야 함|25℃이상의 고온에서는 생육의 정지|11월 까지 낮 온도가 18℃ 이상에서 잎 생육이 촉진되고 겨울 동안 최저 4℃ 이상 조건에서 안정적 재배 가능','Allium Sativum L.'),(8,6,'국화과','염류농도 높은 지역 적품종 선택 : 상추품종군별 염류저항성은 적치마 > 청치마 > 청축면 ≒ 적축면 순으로 감소함|난지지역 멀칭 후 부직포 막덮기, 관수는 점적이나 분수호스, 수확 2~3일전 벗겨서 착색시킴, 일시수확용 품종인 경우 유리함.|시설상추에서 곤충병원성 선충을 이용한 밤나방류 생물적방제 가능','상추는 서늘한 기후에서 생장이 잘되는 호냉성 채소로서 내서성은 약한 편임|생육기간 중 온도가 높아지면 추대, 쓴맛의 증가, 생리적 장해 발생이 증가함.|추대는 적산온도 1,400~1700℃에서 나타남','Lactuca sativa L.'),(9,7,'박과','고밀식 비가림 지주재배(관행재배 대비) : 13~68% 증수|여름철 비닐하우스 이용 비가림재배시 관수방법 개선 (생육 전기간 관수대비) : 착과율 33 → 82% 향상','호온성 작물로 고온에서 생육 양호|개화에서 성숙까지의 적산온도 : 800~1,000℃|건조에는 강하나 다습에는 약하여 피해 발생|연작을 싫어하는 기지성(忌地性)이 강한 작물로 반드시 윤작을 해야함|덩굴쪼김병 방지를 위해 접목재배 실시','Citrullus Vulgaris SCHRAD.'),(10,8,'백합과','지대별 적응 품종 선택 : 조생, 중만생종 등 재배지대별 환경에 알맞은품종 선택 재배|우량묘 : 정식 할 때의 모 규격 엽초 굵기 6~7.5mm, 초장 25~30cm,엽수 4매 적합하고 크면 추대 발생 우려|관수 : 구비대기 4~5월에 7~10일 간격 충분히 관수','양파 종자는 광이 없는 어두운 조건에서 발아 잘 됨|25℃이상의 고온에서는 생육 정지 및 휴면|양파 구 비대에는 일정한 시간 이상의 일장이 있어야 하며 조생종은11.5~13시간, 중만생종은 13~14.3시간이 필요함','Allium cepa L.'),(11,9,'박과','봉지 재배로 규격오이 생산 : 상품과율 향상 및 선별 노동력 절감|관비재배 기술 : 관행대비 수량 증수, 염류집적 감소|일사비례변온관리 : 10~25% 증수, 에너지 절감','자웅이화 작물로서 성분화에는 온도와 일장이 주로 관여|15℃ 정도의 야간저온과 8~10시간의 단일조건에서 암꽃 분화 촉진|단위 결과성이 높은 열매채소|덩굴쪼김병 방제, 저온신장성·내서성 강화, 초세유지를 위해 접목재배','Cucumis sativus L.'),(12,10,'백합과','정식후 효과적인 잡초 제거|병해충 적기방제|북주기를 통한 상품성 향상|토양조건 및 수확시기에 따른 충분한 시비','서늘한 기후에서 생육이 잘되는 채소|일장이 길어지고 온도가 높아지면 잎 끝이 마르면서 하고 현상이 발생하고구를 형성함|짧은 생육 기간','Allium wakegi ARAKI'),(13,11,'가지과','4본유인 재배 : 방임재배 대비 15% 증수|정식 후 70일부터 정지 : 방임재배 대비 18% 증수|착과시에 환경 및 근권스트레스를 통한 적정 착과수 확보|오전은 22℃, 오후는 25℃, 야간은 18～20℃ 온도 유지','중일성 작물로 가지과에 속하는 영년생 작물|줄기는 목본성, 저목형이며 비교적 약함|처음에 외줄기로 자라다가 2개의 가지로 분지|첫번째 분지점에서 1번화인 버들눈(crown bud) 생성|착과 후 35일경에 비대가 완료되어 수확','Capsicum annum L.'),(14,12,'박과','','생육적온 18~30℃ 고온에 약하고, 서리 피해를 입기 쉬움|암꽃 착생은 8시간 정도의 단일 조건에서 촉진|저온 단일조건에서 제1암꽃은 7~ 8절에 착생되며, 그 후에는 4~5절 마다 착생','Cucubita moschata DUCH.');
/*!40000 ALTER TABLE `cultivation_characteristic` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-04-04 10:44:23
