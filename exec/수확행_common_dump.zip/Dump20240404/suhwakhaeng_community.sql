CREATE DATABASE  IF NOT EXISTS `suhwakhaeng` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `suhwakhaeng`;
-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: suhwakhaeng-db.choem88ukglc.ap-northeast-2.rds.amazonaws.com    Database: suhwakhaeng
-- ------------------------------------------------------
-- Server version	8.0.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `community`
--

DROP TABLE IF EXISTS `community`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `community` (
  `community_id` bigint NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) DEFAULT NULL,
  `updated_at` datetime(6) DEFAULT NULL,
  `user_id` bigint DEFAULT NULL,
  `community_content` text,
  `community_image1` varchar(255) DEFAULT NULL,
  `community_image2` varchar(255) DEFAULT NULL,
  `community_image3` varchar(255) DEFAULT NULL,
  `community_image4` varchar(255) DEFAULT NULL,
  `community_cate` enum('QUESTION','SHARE','TIP','FREEDOM') DEFAULT NULL,
  PRIMARY KEY (`community_id`),
  KEY `FKfsfwlfb2ummfsb30q78wo6se0` (`user_id`),
  CONSTRAINT `FKfsfwlfb2ummfsb30q78wo6se0` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `community`
--

LOCK TABLES `community` WRITE;
/*!40000 ALTER TABLE `community` DISABLE KEYS */;
INSERT INTO `community` VALUES (2,'2024-04-03 10:51:14.261070','2024-04-03 10:51:14.261070',3,'감자가 잘 안 자라요...!\n혹시 수경제배 이렇게 하는게 맞을까요?','https://firebasestorage.googleapis.com/v0/b/suhwakhaeng-d9373.appspot.com/o/images%2F%EC%BB%A4%EB%AE%A4%EB%8B%88%ED%8B%B0%2F3%2F2024-04-03%2010%3A51%3A09%2Fimage_0.png?alt=media&token=7b37b635-f917-4ff7-8f95-ffec98af25f6',NULL,NULL,NULL,'QUESTION'),(3,'2024-04-03 10:54:25.764600','2024-04-03 10:54:25.764600',1,'다들 벚꽃 보셨나요??\n이번주가 절정이라고 하더라고요!\n저랑 벚꽃보러 가실분~~','https://firebasestorage.googleapis.com/v0/b/suhwakhaeng-d9373.appspot.com/o/images%2F%EC%BB%A4%EB%AE%A4%EB%8B%88%ED%8B%B0%2F1%2F2024-04-03%2010%3A54%3A19%2Fimage_0.png?alt=media&token=4486c390-c1e8-4df7-b6dc-b6e77d351430',NULL,NULL,NULL,'FREEDOM'),(4,'2024-04-03 10:56:34.151539','2024-04-03 10:56:34.151539',1,'맛있는 점심 즐거운 점심 재밌는 점심을 주세요?','https://firebasestorage.googleapis.com/v0/b/suhwakhaeng-d9373.appspot.com/o/images%2F%EC%BB%A4%EB%AE%A4%EB%8B%88%ED%8B%B0%2F1%2F2024-04-03%2010%3A56%3A29%2Fimage_0.png?alt=media&token=806f83bf-df7c-4253-a50b-7bad93d017e0',NULL,NULL,NULL,'FREEDOM'),(5,'2024-04-03 10:58:49.754790','2024-04-03 10:58:49.754790',1,'댜들 뭐드시나요??\n점심 메뉴 추천받아요!!\n추천 메뉴 댓글에 적어주세요..!!\n\n일단 제가 생각하는 메뉴는 음...... 없습니다!',NULL,NULL,NULL,NULL,'FREEDOM'),(6,'2024-04-03 11:02:49.492749','2024-04-03 11:02:49.492749',3,'상대를 향한 비방, 욕설 등은 삼가해주세요...!\n틈틈히 확인 중입니다!!',NULL,NULL,NULL,NULL,'FREEDOM'),(7,'2024-04-03 11:03:30.572717','2024-04-03 11:03:30.572717',1,'< 목포 맛집 추천 >\n북항 - 이솝(이자카야), 커피창고로(카페)\n평화광장 - 평화수산(횟집)\n\n이솝은 연어랑 오꼬노미야끼 맛있고, 커피 창고로는 에그타르트 맛집이에요!! 나중에 목포가면 드셔보세용ㅎㅎ',NULL,NULL,NULL,NULL,'FREEDOM'),(8,'2024-04-03 11:05:14.597027','2024-04-03 11:05:14.597027',1,'오늘의 감자~~!','https://firebasestorage.googleapis.com/v0/b/suhwakhaeng-d9373.appspot.com/o/images%2F%EC%BB%A4%EB%AE%A4%EB%8B%88%ED%8B%B0%2F1%2F2024-04-03%2011%3A05%3A08%2Fimage_0.png?alt=media&token=3accc26d-470b-4109-bd42-5ea04b7c13d5',NULL,NULL,NULL,'FREEDOM'),(9,'2024-04-03 11:06:51.474120','2024-04-03 11:06:51.474120',1,'삼겹살 드시러 가실 분~\n오늘 광주에서 삼겹살 드실분 찾습니다~~','https://firebasestorage.googleapis.com/v0/b/suhwakhaeng-d9373.appspot.com/o/images%2F%EC%BB%A4%EB%AE%A4%EB%8B%88%ED%8B%B0%2F1%2F2024-04-03%2011%3A06%3A44%2Fimage_0.png?alt=media&token=a6174217-b182-400e-b8c2-c9a0586582d2',NULL,NULL,NULL,'FREEDOM'),(10,'2024-04-03 11:09:28.314185','2024-04-03 11:09:28.314185',1,'레이니 키보드 써보신분?\n한번 사볼까 생각중인데 괜찮나요??\n혹시 좋은 키보드 있으면 추천해주세요!','https://firebasestorage.googleapis.com/v0/b/suhwakhaeng-d9373.appspot.com/o/images%2F%EC%BB%A4%EB%AE%A4%EB%8B%88%ED%8B%B0%2F1%2F2024-04-03%2011%3A09%3A26%2Fimage_0.png?alt=media&token=fe57292f-3e77-46bc-9c92-8f4358259b6e',NULL,NULL,NULL,'FREEDOM'),(11,'2024-04-03 11:12:37.102817','2024-04-03 11:12:37.102817',1,'2달 걸려서 완성했습니다!\n실제로 보면 진짜 이쁘네용ㅎㅎ','https://firebasestorage.googleapis.com/v0/b/suhwakhaeng-d9373.appspot.com/o/images%2F%EC%BB%A4%EB%AE%A4%EB%8B%88%ED%8B%B0%2F1%2F2024-04-03%2011%3A12%3A28%2Fimage_0.png?alt=media&token=028191ca-c746-46f1-b1b5-15f6d58854df',NULL,NULL,NULL,'FREEDOM'),(12,'2024-04-03 11:17:25.752108','2024-04-03 11:17:25.752108',1,'< 공지사항 > \n일정 : 4월 5일\n목적 : 식목일 모임\n위치 : 광주광역시 광산구 풍영로 어딘가\n준비물 : 심을 식물\n\n안녕하세요.\n이번주 식목일을 맞아 행사을 진행합니다.\n행사 일정과 장소를 확인하시고 참여하실 분은 댓글에 이름 남겨주시기 바랍니다.\n궁금한점이 있으면 010-0000-0000으로 연락주세요.\n감사합니다.',NULL,NULL,NULL,NULL,'FREEDOM'),(13,'2024-04-03 11:20:20.407005','2024-04-03 11:20:20.407005',1,'주말에 맥주 드시러 가실분?\n계산은 더치페이입니다.','https://firebasestorage.googleapis.com/v0/b/suhwakhaeng-d9373.appspot.com/o/images%2F%EC%BB%A4%EB%AE%A4%EB%8B%88%ED%8B%B0%2F1%2F2024-04-03%2011%3A20%3A12%2Fimage_0.png?alt=media&token=fdadec00-e28c-45be-a69e-4f2ddb3a450a',NULL,NULL,NULL,'FREEDOM'),(14,'2024-04-03 11:21:52.243149','2024-04-03 11:21:52.243149',1,'와 벌써 4월이네요...\n시간이 왜이렇게 빨리 지나갈까요??\n늦기 전에 꽃보러 다녀와야겠어요....',NULL,NULL,NULL,NULL,'FREEDOM'),(15,'2024-04-03 11:22:59.914782','2024-04-03 11:22:59.914782',1,'오늘의 고양이~','https://firebasestorage.googleapis.com/v0/b/suhwakhaeng-d9373.appspot.com/o/images%2F%EC%BB%A4%EB%AE%A4%EB%8B%88%ED%8B%B0%2F1%2F2024-04-03%2011%3A22%3A55%2Fimage_0.png?alt=media&token=473155a5-972b-435a-a9bb-14d43bacbc3e',NULL,NULL,NULL,'FREEDOM'),(18,'2024-04-03 11:37:45.203512','2024-04-03 11:37:45.203512',1,'포켓몬 스티커 나눔합니다!','https://firebasestorage.googleapis.com/v0/b/suhwakhaeng-d9373.appspot.com/o/images%2F%EC%BB%A4%EB%AE%A4%EB%8B%88%ED%8B%B0%2F1%2F2024-04-03%2011%3A37%3A38%2Fimage_0.png?alt=media&token=67fa4375-46cb-4499-a567-62edd8810b42',NULL,NULL,NULL,'SHARE'),(19,'2024-04-03 11:39:11.408696','2024-04-03 11:39:11.408696',1,'날씨 진짜 좋네요~','https://firebasestorage.googleapis.com/v0/b/suhwakhaeng-d9373.appspot.com/o/images%2F%EC%BB%A4%EB%AE%A4%EB%8B%88%ED%8B%B0%2F1%2F2024-04-03%2011%3A38%3A59%2Fimage_0.png?alt=media&token=326b4b8a-f328-46fe-ac77-51e9b73f24a6',NULL,NULL,NULL,'FREEDOM'),(20,'2024-04-03 11:40:20.441013','2024-04-03 11:40:20.441013',1,'귀여운 춘식이','https://firebasestorage.googleapis.com/v0/b/suhwakhaeng-d9373.appspot.com/o/images%2F%EC%BB%A4%EB%AE%A4%EB%8B%88%ED%8B%B0%2F1%2F2024-04-03%2011%3A40%3A18%2Fimage_0.png?alt=media&token=97a3c4c8-0ba2-4951-8395-e5b9c5d2125a',NULL,NULL,NULL,'FREEDOM'),(21,'2024-04-03 11:42:20.558891','2024-04-03 11:42:20.558891',1,'화과자 좋아하시는분?\n경주에서 사온 화과자인데 나눔합니다!','https://firebasestorage.googleapis.com/v0/b/suhwakhaeng-d9373.appspot.com/o/images%2F%EC%BB%A4%EB%AE%A4%EB%8B%88%ED%8B%B0%2F1%2F2024-04-03%2011%3A42%3A13%2Fimage_0.png?alt=media&token=ea529b40-9de0-4be3-bb1e-5dbc2fdac341',NULL,NULL,NULL,'SHARE'),(22,'2024-04-03 11:44:36.292450','2024-04-03 14:35:40.118878',1,'카페가실분!\n댓글 달아주세요. 5명 모집합니다.\n!!!!!!!\n\n!!!!!!!!!!','https://firebasestorage.googleapis.com/v0/b/suhwakhaeng-d9373.appspot.com/o/images%2F%EC%BB%A4%EB%AE%A4%EB%8B%88%ED%8B%B0%2F1%2F22%2Fimage_0.png?alt=media&token=52a37652-2050-4fd3-9c42-8cbe8f741fbb',NULL,NULL,NULL,'FREEDOM'),(23,'2024-04-03 11:45:10.486802','2024-04-03 11:45:10.486802',1,'광주 장덕동 맛집 추천해주세여!',NULL,NULL,NULL,NULL,'FREEDOM'),(24,'2024-04-03 11:46:22.066592','2024-04-03 11:46:22.066592',1,'안녕하세요! 잘부탁드립니다?',NULL,NULL,NULL,NULL,'FREEDOM'),(25,'2024-04-03 11:50:39.414511','2024-04-03 11:50:39.414511',2,'초밥 굿','https://firebasestorage.googleapis.com/v0/b/suhwakhaeng-d9373.appspot.com/o/images%2F%EC%BB%A4%EB%AE%A4%EB%8B%88%ED%8B%B0%2F2%2F2024-04-03%2011%3A50%3A33%2Fimage_0.png?alt=media&token=28c038a8-0feb-456d-96bd-cf8d81a9eae4',NULL,NULL,NULL,'FREEDOM'),(26,'2024-04-03 11:57:35.530269','2024-04-03 11:57:35.530269',1,' < 양파 육묘 방법 >\n\n양파 육묘 방법 공유합니다.\n\n파종기 : 8중순 ∼ 11월중순(지역 및 작형에 따라 시기가 다름)\n묘상 준비\n적지선정 : 비옥하고 보수력이 있으며 2∼3년간 파속을 재배하지 않은곳\n묘상면적 : 본포 10a당(300평) 40∼50㎡(12∼15평)\n시비량(g/3.3㎡) : 퇴비 18kg, 요소 87g, 용성인비 200g, 염화칼리 67g\n시비 시기 : 파종 10∼15일전 밑거름으로 전량 뿌려줌\n파종량 : 본포 10a당(300평) 종자 6∼8㎗(3∼4홉)\n파종방법(줄뿌림)\n이랑넓이 90∼120cm, 고랑넓이 30∼40cm\n6∼9cm 간격으로 0.5cm 깊이의 골을 만듬\n종자를 0.5cm 간격으로 놓고 고은흙, 모래, 상토, 톱밥 등으로 덮어줌',NULL,NULL,NULL,NULL,'TIP'),(27,'2024-04-03 11:59:22.757915','2024-04-03 14:11:49.759503',1,'< 양파 정식 요령 >\n\n양파 정식 요령 공유합니다.\n\n정식기 : 10월 상순 ∼ 11월 상순\n시비량(10a당) : 퇴비3,000kg, 요소52.2kg, 용성인비38.5kg 염화칼리25.6kg\n시비방법\n밑거름으로 퇴비, 용성인비 전량과 요소 17.4, 염화칼리 15.2kg을 정식전에 뿌리고 경운 로타리작업과 이랑과 골을 만듬\n정식방법\n묘 소요량 : 10a당(300평) 33,000주\n좋은묘 고르기 : 줄기굵기 6∼7.5mm, 키 25∼30cm, 엽수 4매 정도\n심는거리 : 120cm 두둑에 6줄로 하고 포기사이 15cm(지역에따라 다름)\n심는깊이 : 3cm로 하고 곧게 세우고 쓰러지지 않도록 흙을 가볍에 눌러줌\n비닐멀칭\n정식전에 투명비닐이나 흑색비닐을 덮음++',NULL,NULL,NULL,NULL,'TIP'),(42,'2024-04-04 10:17:41.728623','2024-04-04 10:17:41.728623',1,'감자가 잘 자라고 있나요??\n지금 키운지 3주 정도 되었습니다!','https://firebasestorage.googleapis.com/v0/b/suhwakhaeng-d9373.appspot.com/o/images%2F%EC%BB%A4%EB%AE%A4%EB%8B%88%ED%8B%B0%2F1%2F2024-04-04%2010%3A17%3A36%2Fimage_0.png?alt=media&token=d0c2cd59-6082-420e-b599-5d21bbc5e29d',NULL,NULL,NULL,'QUESTION');
/*!40000 ALTER TABLE `community` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-04-04 10:44:27
