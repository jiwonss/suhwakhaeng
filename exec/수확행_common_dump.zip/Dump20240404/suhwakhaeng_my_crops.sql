CREATE DATABASE  IF NOT EXISTS `suhwakhaeng` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `suhwakhaeng`;
-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: suhwakhaeng-db.choem88ukglc.ap-northeast-2.rds.amazonaws.com    Database: suhwakhaeng
-- ------------------------------------------------------
-- Server version	8.0.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `my_crops`
--

DROP TABLE IF EXISTS `my_crops`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `my_crops` (
  `my_crops_area` double DEFAULT NULL,
  `my_crops_yield` int DEFAULT NULL,
  `crops_variety_id` bigint DEFAULT NULL,
  `my_crops_id` bigint NOT NULL,
  `user_id` bigint DEFAULT NULL,
  `dong` varchar(255) DEFAULT NULL,
  `gugun` varchar(255) DEFAULT NULL,
  `my_crops_name` varchar(255) DEFAULT NULL,
  `sido` varchar(255) DEFAULT NULL,
  `my_crops_area_unit` enum('SQUARE_METER','PYEONG','HECTARE') DEFAULT NULL,
  PRIMARY KEY (`my_crops_id`),
  KEY `FK7k3lbob64l3kt1skpet4v1pem` (`crops_variety_id`),
  KEY `FKamx9teo19u4u3osna3vofk7o3` (`user_id`),
  CONSTRAINT `FK7k3lbob64l3kt1skpet4v1pem` FOREIGN KEY (`crops_variety_id`) REFERENCES `crops_variety` (`crops_variety_id`),
  CONSTRAINT `FKamx9teo19u4u3osna3vofk7o3` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `my_crops`
--

LOCK TABLES `my_crops` WRITE;
/*!40000 ALTER TABLE `my_crops` DISABLE KEYS */;
INSERT INTO `my_crops` VALUES (50,45,18,1,4,'임곡리','기장군','수린이','부산','SQUARE_METER'),(1616161,15,14,102,3,'탄방리','예산군','Sndjdjdj','충남','SQUARE_METER'),(49449,1919,16,103,3,'오리','기장군','ㅋ','부산','SQUARE_METER'),(151551,45,3,104,3,NULL,NULL,'ㄴㅈㄴㅈㄴ',NULL,'SQUARE_METER'),(55,55,17,105,52,'일도이동','제주시','수린이','제주특별자치도','SQUARE_METER'),(5645,50000,18,107,102,'자양리','순창군','아코','전북특별자치도','SQUARE_METER'),(35,10,4,152,2,'봉선동','남구','나는 감자','광주','SQUARE_METER'),(55,30,9,155,152,'금호동','서구','고추우','광주','SQUARE_METER'),(52,19,18,156,2,'방림동','남구','당근','광주','SQUARE_METER'),(10000,10,2,157,1,'지평동','광산구','감순이','광주','SQUARE_METER'),(2000,0,23,158,1,'달동','목포시','상순이','전남','SQUARE_METER'),(0,0,28,159,1,'무안동','목포시','파파','전남','SQUARE_METER');
/*!40000 ALTER TABLE `my_crops` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-04-04 10:44:25
